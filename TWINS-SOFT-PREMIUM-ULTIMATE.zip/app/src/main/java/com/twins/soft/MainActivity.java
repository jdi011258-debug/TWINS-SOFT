package com.twins.soft;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.StatFs;
import android.view.*;
import android.widget.Toast;
import java.io.File;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    PremiumView view;
    final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(0,3,10));
        getWindow().setNavigationBarColor(Color.rgb(0,3,10));
        showSplash();
    }

    void showSplash() {
        SplashView splash = new SplashView(this);
        setContentView(splash);
        handler.postDelayed(() -> { view = new PremiumView(this); setContentView(view); }, 4200);
    }

    void haptic() {
        try { ((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(25); } catch (Exception ignored) {}
    }

    long folderSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0; File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) { s += folderSize(x); if (s > 1024L*1024*1024) break; }
        return s;
    }

    String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024*1024) return String.format(Locale.US,"%.0f KB",n/1024.0);
        if (n < 1024L*1024*1024) return String.format(Locale.US,"%.1f MB",n/(1024.0*1024));
        return String.format(Locale.US,"%.2f GB",n/(1024.0*1024*1024));
    }

    long freeStorage() {
        try { StatFs s = new StatFs(getFilesDir().getAbsolutePath()); return s.getAvailableBytes(); } catch(Exception e){ return 0; }
    }
    long totalStorage() {
        try { StatFs s = new StatFs(getFilesDir().getAbsolutePath()); return s.getTotalBytes(); } catch(Exception e){ return 0; }
    }
    int battery() {
        try {
            Intent i=getRegisterReceiver(null,new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int l=i.getIntExtra("level",0), sc=i.getIntExtra("scale",100); return sc>0?(l*100/sc):0;
        } catch(Exception e){ return 0; }
    }

    void scan() {
        view.startScan(); haptic();
        new Thread(() -> {
            long total = folderSize(getCacheDir());
            File ext = getExternalCacheDir(); if (ext != null) total += folderSize(ext);
            SystemClock.sleep(2600);
            final long result=total;
            runOnUiThread(() -> view.finishScan(result));
        }).start();
    }

    void clean() {
        new AlertDialog.Builder(this)
            .setTitle("تنظيف TWINS الآمن")
            .setMessage("سيتم حذف مخلفات Cache الخاصة بالتطبيق فقط. لن يتم حذف الصور أو الفيديوهات أو المستندات أو الملفات الشخصية.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("تنظيف الآن", (d,w) -> {
                deleteChildren(getCacheDir());
                File e=getExternalCacheDir(); if(e!=null) deleteChildren(e);
                view.junkBytes=0; view.scanned=true; view.cleanFlash=1f; view.message="اكتمل التنظيف بأمان ✨"; view.invalidate(); haptic();
                Toast.makeText(this,"تم تنظيف مخلفات التطبيق بأمان ✨",Toast.LENGTH_SHORT).show();
            }).show();
    }
    void deleteChildren(File dir){ if(dir==null)return; File[] fs=dir.listFiles(); if(fs==null)return; for(File f:fs) deleteRec(f); }
    void deleteRec(File f){ if(f.isDirectory()){File[] x=f.listFiles(); if(x!=null)for(File c:x)deleteRec(c);} try{f.delete();}catch(Exception ignored){} }

    class SplashView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); Bitmap logo; float t=0;
        Runnable anim=()->{t+=.045f;invalidate();postDelayed(this.anim,32);};
        SplashView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);logo=BitmapFactory.decodeResource(getResources(),R.drawable.app_icon);post(anim);}
        void txt(Canvas c,String s,float x,float y,float z,int col,boolean bold){p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(z);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight(),cx=w/2,cy=h*.32f;c.drawColor(Color.BLACK);
            LinearGradient g=new LinearGradient(0,0,w,h,Color.rgb(0,25,62),Color.rgb(0,2,9),Shader.TileMode.CLAMP);p.setShader(g);c.drawRect(0,0,w,h,p);p.setShader(null);
            float pulse=(float)Math.sin(t)*6;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(0,185,255));p.setShadowLayer(30,0,0,Color.rgb(0,100,255));c.drawCircle(cx,cy,130+pulse,p);p.clearShadowLayer();
            p.setStrokeWidth(2);p.setColor(Color.rgb(80,225,255));c.drawCircle(cx,cy,111+pulse*.5f,p);
            if(logo!=null)c.drawBitmap(logo,null,new RectF(cx-101,cy-101,cx+101,cy+101),p);
            txt(c,"TWINS SOFT",cx,cy+165,30,Color.WHITE,true);
            txt(c,"هــديــة مــقــدمــة مــن TWINS",cx,cy+213,19,Color.rgb(90,225,255),true);
            txt(c,"لصيانة وبرمجة الإلكترونيات",cx,cy+245,16,Color.rgb(220,235,245),false);
            txt(c,"تنظيف ذكي • حماية آمنة • أداء أفضل",cx,cy+292,12,Color.rgb(120,165,195),false);
            float a=(float)((Math.sin(t*1.6)+1)/2);p.setStrokeWidth(3);p.setColor(Color.rgb(0,180,255));c.drawLine(w*.22f,h*.79f,w*(.22f+.56f*a),h*.79f,p);
            txt(c,"جاري تشغيل التجربة الفاخرة...",cx,h*.84f,11,Color.rgb(70,150,190),false);
        }
    }

    class PremiumView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); RectF r=new RectF(); Random rnd=new Random(8);
        boolean scanning=false,scanned=false; long junkBytes=0; float progress=0,pulse=0,cleanFlash=0; String phase="جاهز للانطلاق",message="";
        float[] dustX=new float[34],dustY=new float[34];
        Runnable ticker=new Runnable(){public void run(){pulse+=.055f;if(scanning){progress=Math.min(.985f,progress+.0115f);if(progress<.28f)phase="فحص الذاكرة المؤقتة...";else if(progress<.55f)phase="تحليل المخلفات الآمنة...";else if(progress<.78f)phase="حماية الملفات الشخصية...";else phase="إنهاء الفحص الذكي...";}if(cleanFlash>0)cleanFlash-=.035f;invalidate();postDelayed(this,32);}};
        PremiumView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);for(int i=0;i<dustX.length;i++){dustX[i]=rnd.nextFloat();dustY[i]=rnd.nextFloat();}post(ticker);}
        void fill(Canvas c,int col){p.setStyle(Paint.Style.FILL);p.setColor(col);p.setShader(null);p.setAlpha(255);}
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int col){fill(c,col);r.set(l,t,rr,bb);c.drawRoundRect(r,rad,rad,p);}
        void text(Canvas c,String s,float x,float y,float z,int col,Paint.Align a,boolean bold){fill(c,col);p.setTextSize(z);p.setTextAlign(a);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
        void strokeRound(Canvas c,float l,float t,float rr,float bb,float rad,int col){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.4f);p.setColor(col);r.set(l,t,rr,bb);c.drawRoundRect(r,rad,rad,p);}
        void glowCircle(Canvas c,float x,float y,float rad,int col,float alpha){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(col);p.setAlpha((int)(alpha*255));p.setShadowLayer(20,0,0,col);c.drawCircle(x,y,rad,p);p.clearShadowLayer();p.setAlpha(255);}
        void card(Canvas c,float x,float y,float cw,String title,String value,String sub){round(c,x,y,x+cw,y+80,18,Color.rgb(5,16,29));strokeRound(c,x,y,x+cw,y+80,18,Color.rgb(18,70,100));text(c,title,x+14,y+23,10,Color.rgb(130,175,200),Paint.Align.LEFT,true);text(c,value,x+14,y+49,16,Color.WHITE,Paint.Align.LEFT,true);text(c,sub,x+14,y+68,8.5f,Color.rgb(85,130,155),Paint.Align.LEFT,false);}
        protected void onDraw(Canvas c){
            super.onDraw(c);float w=getWidth(),h=getHeight();c.drawColor(Color.rgb(2,7,18));
            LinearGradient bg=new LinearGradient(0,0,w,h,Color.rgb(5,20,46),Color.rgb(2,6,16),Shader.TileMode.CLAMP);p.setShader(bg);c.drawRect(0,0,w,h,p);p.setShader(null);
            fill(c,Color.rgb(0,60,120));p.setAlpha(30);c.drawCircle(w*.08f,h*.16f,170,p);c.drawCircle(w*.92f,h*.36f,160,p);p.setAlpha(255);
            // floating tech particles
            for(int i=0;i<dustX.length;i++){float x=(dustX[i]*w+(float)Math.sin(pulse+i)*7+w)%w;float y=(dustY[i]*h+((pulse*12+i*13)%h))%h;fill(c,Color.rgb(40,150,210));p.setAlpha(45+(i%3)*20);c.drawCircle(x,y,1.2f+(i%3),p);}p.setAlpha(255);
            text(c,"TWINS",w/2,43,26,Color.WHITE,Paint.Align.CENTER,true);text(c,"SOFT",w/2,67,13,Color.rgb(60,195,255),Paint.Align.CENTER,true);text(c,"SMART CLEAN • SAFE SHIELD",w/2,87,8,Color.rgb(100,145,175),Paint.Align.CENTER,false);
            float cx=w/2,cy=194,spin=pulse*70;
            glowCircle(c,cx,cy,91+(float)Math.sin(pulse)*4,Color.rgb(0,150,255),.45f);glowCircle(c,cx,cy,76,Color.rgb(0,225,255),.72f);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(55,170,220));r.set(cx-62,cy-62,cx+62,cy+62);c.drawArc(r,spin,110,false,p);c.drawArc(r,spin+180,70,false,p);
            fill(c,Color.rgb(5,19,36));c.drawCircle(cx,cy,61,p);
            Path sh=new Path();sh.moveTo(cx,cy-36);sh.lineTo(cx+30,cy-20);sh.lineTo(cx+26,cy+22);sh.quadTo(cx,cy+49,cx-26,cy+22);sh.lineTo(cx-30,cy-20);sh.close();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor(Color.rgb(55,215,255));p.setShadowLayer(14,0,0,Color.rgb(0,150,255));c.drawPath(sh,p);p.clearShadowLayer();
            text(c,scanning?((int)(progress*100))+"%":(scanned?"100%":"SAFE"),cx,cy+6,18,Color.WHITE,Paint.Align.CENTER,true);text(c,scanning?phase:(scanned?"تم الفحص بنجاح":"هاتفك جاهز للفحص"),cx,cy+29,9.5f,Color.rgb(145,190,220),Paint.Align.CENTER,false);
            if(scanning){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(0,205,255));r.set(cx-98,cy-98,cx+98,cy+98);c.drawArc(r,-90,progress*360,false,p);p.setStrokeCap(Paint.Cap.BUTT);}
            float top=290;round(c,22,top,w-22,top+66,21,Color.rgb(7,27,46));strokeRound(c,22,top,w-22,top+66,21,Color.rgb(0,160,255));text(c,scanning?"يتم الفحص الآن...":(scanned?"إعادة الفحص الذكي":"ابدأ الفحص الذكي"),w/2,top+29,17,Color.WHITE,Paint.Align.CENTER,true);text(c,scanning?"نحلل المخلفات الآمنة ونحمي ملفاتك":(scanned?"تم التحليل — يمكنك التنظيف بأمان":"تنظيف Cache • فحص سريع • حماية الملفات"),w/2,top+49,9.5f,Color.rgb(115,175,210),Paint.Align.CENTER,false);
            float y=380,gap=10,cw=(w-44-gap)/2;
            card(c,22,y,cw,"المخلفات الآمنة",scanned?size(junkBytes):"جاهز","Cache التطبيق فقط");
            card(c,22+cw+gap,y,cw,"حماية الملفات","100%","لا حذف للصور الشخصية");
            card(c,22,y+94,cw,"التخزين الحر",size(freeStorage()),"المساحة المتاحة");
            card(c,22+cw+gap,y+94,cw,"البطارية",battery()+"%","حالة البطارية الآن");
            card(c,22,y+188,cw,"الفحص الحي",scanning?"LIVE":"READY","تفاعل بصري متحرك");
            card(c,22+cw+gap,y+188,cw,"الوضع الآمن","ON","حذف Cache فقط");
            float by=h-105;round(c,22,by,w-22,by+54,17,Color.rgb(6,17,30));strokeRound(c,22,by,w-22,by+54,17,Color.rgb(20,80,110));text(c,"تنظيف المخلفات",w*.30f,by+22,12,Color.WHITE,Paint.Align.CENTER,true);text(c,scanned?size(junkBytes):"بعد الفحص",w*.30f,by+40,9,Color.rgb(65,205,255),Paint.Align.CENTER,false);text(c,"تنظيف آمن",w*.73f,by+30,13,Color.rgb(90,225,255),Paint.Align.CENTER,true);
            text(c,message.length()>0?message:"TWINS SOFT • PREMIUM • 1.0",w/2,h-30,9.5f,message.length()>0?Color.rgb(80,220,255):Color.rgb(70,105,130),Paint.Align.CENTER,false);
            if(cleanFlash>0){fill(c,Color.rgb(0,190,255));p.setAlpha((int)(cleanFlash*55));c.drawCircle(cx,cy,120+100*(1-cleanFlash),p);p.setAlpha(255);}
        }
        void startScan(){if(scanning)return;scanning=true;scanned=false;progress=0;message="";haptic();invalidate();}
        void finishScan(long b){scanning=false;scanned=true;progress=1;junkBytes=b;phase="اكتمل التحليل";message="الفحص اكتمل — ملفاتك الشخصية لم تُلمس";haptic();invalidate();Toast.makeText(MainActivity.this,"اكتمل الفحص الذكي ✨",Toast.LENGTH_SHORT).show();}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float y=e.getY(),h=getHeight();if(y>=275&&y<=370){if(!scanning)scan();return true;}if(y>=h-125&&y<=h-40){if(scanned&&junkBytes>0)clean();else {scan();}return true;}return true;}
    }
}
