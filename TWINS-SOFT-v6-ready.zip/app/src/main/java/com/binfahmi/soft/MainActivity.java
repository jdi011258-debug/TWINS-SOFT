package com.binfahmi.soft;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

import java.io.File;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(9, 11, 18));

        TextView title = new TextView(this);
        title.setText("TWINS SOFT");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("تنظيف وحماية الهاتف بطريقة آمنة");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(17);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("\nجاهز للفحص");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        Button scan = new Button(this);
        scan.setText("بدء الفحص الآمن");
        scan.setOnClickListener(v -> {
            long freeBytes = Environment.getExternalStorageDirectory().getFreeSpace();
            long freeMb = freeBytes / 1024 / 1024;
            status.setText("اكتمل الفحص\nالمساحة الحرة: " + freeMb + " MB\nلم يتم حذف أي ملفات شخصية.");
        });
        root.addView(scan, new LinearLayout.LayoutParams(-1, -2));

        Button cache = new Button(this);
        cache.setText("تنظيف كاش التطبيق");
        cache.setOnClickListener(v -> {
            try {
                deleteContents(getCacheDir());
                status.setText("تم تنظيف كاش التطبيق بأمان.");
            } catch (Exception e) {
                status.setText("تعذر تنظيف الكاش.");
            }
        });
        root.addView(cache, new LinearLayout.LayoutParams(-1, -2));

        Button storage = new Button(this);
        storage.setText("إدارة التخزين الرسمية");
        storage.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        root.addView(storage, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private static void deleteContents(File directory) {
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) {
                deleteContents(file);
            }
            file.delete();
        }
    }
}
